-- Exerc�cio 4.1.2;

DROP TABLE IF EXISTS Voos.Can_Land;
DROP TABLE IF EXISTS Voos.Seat;
DROP TABLE IF EXISTS Voos.Flight_Leg;
DROP TABLE IF EXISTS Voos.Fare;
DROP TABLE IF EXISTS Voos.Leg_Instance;
DROP TABLE IF EXISTS Voos.Flight;
DROP TABLE IF EXISTS Voos.Airplane;
DROP TABLE IF EXISTS Voos.Airplane_Type;
DROP TABLE IF EXISTS Voos.Airport;
DROP SCHEMA IF EXISTS Voos;
GO

CREATE SCHEMA Voos;
GO

CREATE TABLE Voos.Airport(
	Airport_Code			VARCHAR(5)	NOT NULL,
	City					VARCHAR(15)	NOT NULL,
	State_Air				VARCHAR(15)	NOT NULL,
	Name_Air				VARCHAR(30)	NOT NULL,
	DA_Scheduled_dep_time	TIME		NOT NULL,
	AA_Scheduled_dep_time	TIME		NOT NULL,
	Departs_Dep_Time		TIME		NOT NULL,
	Arrives_Arr_Time		TIME		NOT NULL,
	PRIMARY KEY(Airport_Code),
);

CREATE TABLE Voos.Airplane_Type(
	TypeName			VARCHAR(10)	NOT NULL,
	Company				VARCHAR(15)	NOT NULL,
	Max_Seats			INT			NOT NULL,
	PRIMARY KEY(TypeName),
);

CREATE TABLE Voos.Airplane(
	Airplane_ID			VARCHAR(5)	NOT NULL,
	Total_no_of_seats	INT			NOT NULL,
	TypeAirplane		VARCHAR(10)	NOT NULL,
	PRIMARY KEY(Airplane_ID),
	FOREIGN KEY (TypeAirplane) REFERENCES Voos.Airplane_Type(TypeName),
);

CREATE TABLE Voos.Flight(
	Number			INT			NOT NULL,
	Weekdays		VARCHAR(15)	NOT NULL,
	Airline			VARCHAR(15)	NOT NULL,
	A_Airport_Code	VARCHAR(5)	NOT NULL,
	PRIMARY KEY (Number),
	FOREIGN KEY (A_Airport_Code) REFERENCES Voos.Airport(Airport_Code),
);


CREATE TABLE Voos.Leg_Instance(
	No_of_avail_seats	INT		    NOT NULL,
	Date_LI	            DATE	    NOT NULL,
	Departs_Dep_Time	TIME	    NOT NULL,
	Arrives_Arr_Time	TIME	    NOT NULL,
	Res_Customer_Name	VARCHAR(20) NOT NULL,
	Res_Cphone			INT			NOT NULL,
	F_Number			INT			NOT NULL,
	A_Airport_Code		VARCHAR(5)  NOT NULL,
	Airplane_ID			VARCHAR(5)  NOT NULL,
	PRIMARY KEY(F_Number,A_Airport_Code),
	FOREIGN KEY (F_Number) REFERENCES Voos.Flight(Number),
	FOREIGN KEY (A_Airport_Code) REFERENCES Voos.Airport(Airport_Code),
	FOREIGN KEY (Airplane_ID) REFERENCES Voos.Airplane(Airplane_ID),
);

CREATE TABLE Voos.Fare(
	Code			INT			NOT NULL,
	Amount			INT			NOT NULL,
	Restrictions	VARCHAR(30),
	F_Number		INT			NOT NULL,
	PRIMARY KEY (F_Number),
	FOREIGN KEY (F_Number) REFERENCES Voos.Flight(Number),
);

CREATE TABLE Voos.Flight_Leg(
	Leg_No					INT			NOT NULL,
	DA_Scheduled_dep_time	TIME		NOT NULL,
	AA_Scheduled_dep_time	TIME		NOT NULL,
	F_Number				INT			NOT NULL,
	A_Airport_Code			VARCHAR(5)	NOT NULL,
	PRIMARY KEY(F_Number,A_Airport_Code),
	FOREIGN KEY (F_Number) REFERENCES Voos.Flight(Number),
	FOREIGN KEY (A_Airport_Code) REFERENCES Voos.Airport(Airport_Code),
);

CREATE TABLE Voos.Seat(
	Seat_No					INT			NOT NULL,
	Res_Customer_Name		VARCHAR(20) NOT NULL,
	Res_Cphone				INT			NOT NULL,
	F_Number				INT			NOT NULL,
	A_Airport_Code			VARCHAR(5)	NOT NULL,
	PRIMARY KEY(F_Number,A_Airport_Code),
	FOREIGN KEY (F_Number) REFERENCES Voos.Flight(Number),
	FOREIGN KEY (A_Airport_Code) REFERENCES Voos.Airport(Airport_Code),
);

CREATE TABLE Voos.Can_Land(
	A_Airport_Code	VARCHAR(5)	NOT NULL,
	Airplane_Type	VARCHAR(10)	NOT NULL,
	PRIMARY KEY(A_Airport_Code, Airplane_Type),
	FOREIGN KEY (A_Airport_Code) REFERENCES Voos.Airport(Airport_Code),
	FOREIGN KEY (Airplane_Type) REFERENCES Voos.Airplane_Type(TypeName),
);








