-- Exerc�cio 4.1.4;

DROP TABLE IF EXISTS PE_Medicamentos.Produzido;
DROP TABLE IF EXISTS PE_Medicamentos.Farmaceutica;
DROP TABLE IF EXISTS PE_Medicamentos.Vendido;
DROP TABLE IF EXISTS PE_Medicamentos.Envolve;
DROP TABLE IF EXISTS PE_Medicamentos.Farmaco;
DROP TABLE IF EXISTS PE_Medicamentos.Prescricao;
DROP TABLE IF EXISTS PE_Medicamentos.Farmacia;
DROP TABLE IF EXISTS PE_Medicamentos.Medico;
DROP TABLE IF EXISTS PE_Medicamentos.Paciente;
DROP SCHEMA IF EXISTS PE_Medicamentos;
GO

CREATE SCHEMA PE_Medicamentos;
GO

CREATE TABLE PE_Medicamentos.Paciente(
	Nome		VARCHAR(30)	NOT NULL,
	Num_Utente	INT			NOT NULL,
	Endereco	VARCHAR(30)	NOT NULL,
	Data_Nasc	Date		NOT NULL,
	PRIMARY KEY(Num_Utente),
);

CREATE TABLE PE_Medicamentos.Medico(
	Num_Identificacao	INT			NOT NULL,
	Nome				VARCHAR(20)	NOT NULL,
	Especialidade		VARCHAR(20)	NOT NULL,
	PRIMARY KEY(Num_Identificacao),
);

CREATE TABLE PE_Medicamentos.Farmacia(
	NIF						INT			NOT NULL,
	Nome					VARCHAR(20)	NOT NULL,
	Endereco				VARCHAR(20)	NOT NULL,
	Telefone				INT			NOT NULL,
	Data_Process_Prescricao DATE NOT NULL,
	PRIMARY KEY(NIF),
);

CREATE TABLE PE_Medicamentos.Prescricao(
	Data_P				Date		NOT NULL,
	Numero				INT			NOT NULL,
	N_Utente_Paciente	INT			NOT NULL,
	ID_Medico			INT			NOT NULL,
	Data_Process		Date		NOT NULL,
	NIF_Farmacia		INT			NOT NULL
	PRIMARY KEY(Numero),
	FOREIGN KEY (N_Utente_Paciente) REFERENCES PE_Medicamentos.Paciente(Num_Utente),
	FOREIGN KEY (ID_Medico) REFERENCES PE_Medicamentos.Medico(Num_Identificacao),
	FOREIGN KEY (NIF_Farmacia) REFERENCES PE_Medicamentos.Farmacia(NIF),
);

CREATE TABLE PE_Medicamentos.Farmaco(
	Nome_Comercial	VARCHAR(20)	NOT NULL,
	Formula			VARCHAR(20)	NOT NULL,
	PRIMARY KEY (Nome_Comercial, Formula),
);

CREATE TABLE PE_Medicamentos.Envolve(
	N_Prescricao			INT			NOT NULL,
	Formula_Farmaco			VARCHAR(20)	NOT NULL,
	Nome_Comercial_Farmaco	VARCHAR(20)	NOT NULL,
	PRIMARY KEY (N_Prescricao, Formula_Farmaco, Nome_Comercial_Farmaco),
	FOREIGN KEY (N_Prescricao) REFERENCES PE_Medicamentos.Prescricao(Numero),
	FOREIGN KEY (Nome_Comercial_Farmaco, Formula_Farmaco) REFERENCES PE_Medicamentos.Farmaco(Nome_Comercial, Formula),
);

CREATE TABLE PE_Medicamentos.Vendido(
	NIF_Farmacia			INT			NOT NULL,
	Formula_Farmaco			VARCHAR(20)	NOT NULL,
	Nome_Comercial_Farmaco	VARCHAR(20)	NOT NULL,
	PRIMARY KEY (NIF_Farmacia, Formula_Farmaco, Nome_Comercial_Farmaco),
	FOREIGN KEY (NIF_Farmacia) REFERENCES PE_Medicamentos.Farmacia(NIF),
	FOREIGN KEY (Nome_Comercial_Farmaco, Formula_Farmaco) REFERENCES PE_Medicamentos.Farmaco(Nome_Comercial, Formula),
);

CREATE TABLE PE_Medicamentos.Farmaceutica(
	N_Registo	INT			NOT NULL,
	Nome		VARCHAR(20)	NOT NULL,
	Endereco	VARCHAR(20)	NOT NULL,
	Telefone	INT			NOT NULL,
	PRIMARY KEY (N_Registo),
);

CREATE TABLE PE_Medicamentos.Produzido(
	N_Registo_Farmaceutica	INT			NOT NULL,
	Formula_Farmaco			VARCHAR(20)	NOT NULL,
	Nome_Comercial_Farmaco	VARCHAR(20)	NOT NULL,
	PRIMARY KEY (N_Registo_Farmaceutica, Formula_Farmaco, Nome_Comercial_Farmaco),
	FOREIGN KEY (N_Registo_Farmaceutica) REFERENCES PE_Medicamentos.Farmaceutica(N_Registo),
	FOREIGN KEY (Nome_Comercial_Farmaco, Formula_Farmaco) REFERENCES PE_Medicamentos.Farmaco(Nome_Comercial, Formula),
);







