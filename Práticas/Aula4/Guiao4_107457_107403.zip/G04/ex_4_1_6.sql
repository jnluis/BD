-- Exerc�cio 4.1.6;

DROP TABLE IF EXISTS ATL.Paga;
DROP TABLE IF EXISTS ATL.Atividade;
DROP TABLE IF EXISTS ATL.Participa;
DROP TABLE IF EXISTS ATL.Atividades;
DROP TABLE IF EXISTS ATL.Entregar_Levantar;
DROP TABLE IF EXISTS ATL.Aluno;
DROP TABLE IF EXISTS ATL.Pessoa_Autorizada;
DROP TABLE IF EXISTS ATL.Enc_Educacao;
DROP TABLE IF EXISTS ATL.Mensalidade;
DROP TABLE IF EXISTS ATL.Pagamento;
DROP TABLE IF EXISTS ATL.ATL;
DROP TABLE IF EXISTS ATL.Turma;
DROP TABLE IF EXISTS ATL.Professor;
DROP SCHEMA IF EXISTS ATL;
GO

CREATE SCHEMA ATL;
GO

CREATE TABLE ATL.Professor(
	Nome			VARCHAR(30)	NOT NULL,
	Num_CC			INT			NOT NULL,
	Data_Nasc		DATE		NOT NULL,
	Morada			VARCHAR(30)	NOT NULL,
	Telefone		INT			NOT NULL,
	Email			VARCHAR(30),
	Num_Funcionario	INT			NOT NULL,
	PRIMARY KEY(Num_Funcionario),
);

CREATE TABLE ATL.Turma(
	Ano_Letivo		VARCHAR(9)	NOT NULL,
	Identificador	VARCHAR(3)	NOT NULL,
	Desginacao		VARCHAR(15)	NOT NULL,
	Professor		VARCHAR(30),
	Num_Max_Alunos	INT			NOT NULL,
	Num_Professor	INT,
	PRIMARY KEY(Identificador),
	FOREIGN KEY(Num_Professor) REFERENCES ATL.Professor(Num_Funcionario),
);

CREATE TABLE ATL.ATL(
	ID_Turma		VARCHAR(3)	NOT NULL,
	Escolaridade	VARCHAR(10)	NOT NULL,
	PRIMARY KEY(ID_Turma),
	FOREIGN KEY(ID_Turma) REFERENCES ATL.Turma(Identificador),
);

CREATE TABLE ATL.Pagamento(
	Preco		INT	NOT NULL,
	ID			INT	NOT NULL,
	Desconto	INT,
	ID_ATL		VARCHAR(3),
	PRIMARY KEY(ID),
	FOREIGN KEY(ID_ATL) REFERENCES ATL.ATL(ID_Turma),
);

CREATE TABLE ATL.Mensalidade(
	ID_Pagamento	INT	NOT NULL,
	PRIMARY KEY(ID_Pagamento),
	FOREIGN KEY(ID_Pagamento) REFERENCES ATL.Pagamento(ID),
);

CREATE TABLE ATL.Enc_Educacao(
	Nome			VARCHAR(30)	NOT NULL,
	Num_CC			INT			NOT NULL,
	Data_Nasc		DATE		NOT NULL,
	Morada			VARCHAR(30)	NOT NULL,
	Telefone		INT			NOT NULL,
	Email			VARCHAR(30),
	Relacao_Aluno	VARCHAR(10)	NOT NULL,
	Mensalidade		INT,
	PRIMARY KEY(Num_CC),
	FOREIGN KEY(Mensalidade) REFERENCES ATL.Mensalidade(ID_Pagamento),
);

CREATE TABLE ATL.Pessoa_Autorizada(
	Nome			VARCHAR(30)	NOT NULL,
	Num_CC			INT			NOT NULL,
	Data_Nasc		DATE		NOT NULL,
	Morada			VARCHAR(30),
	Telefone		INT			NOT NULL,
	Email			VARCHAR(30),
	Relacao_Aluno	VARCHAR(10)	NOT NULL,
	PRIMARY KEY(Num_CC),
);

CREATE TABLE ATL.Aluno(
	Nome			VARCHAR(30)	NOT NULL,
	Num_CC			INT			NOT NULL,
	Data_Nasc		DATE		NOT NULL,
	Morada			VARCHAR(30)	NOT NULL,
	ID_Turma		VARCHAR(3)	NOT NULL,
	CC_EE			INT			NOT NULL,
	Relacao_EE		VARCHAR(10)	NOT NULL,
	PRIMARY KEY(Num_CC),
	FOREIGN KEY(ID_Turma) REFERENCES ATL.Turma(Identificador),
	FOREIGN KEY(CC_EE) REFERENCES ATL.Enc_Educacao(Num_CC),
);

CREATE TABLE ATL.Entregar_Levantar(
	CC_Aluno			INT	NOT NULL,
	CC_PessoaAutorizada	INT NOT NULL,
	PRIMARY KEY(CC_Aluno, CC_PessoaAutorizada),
	FOREIGN KEY(CC_Aluno) REFERENCES ATL.Aluno(Num_CC),
	FOREIGN KEY(CC_PessoaAutorizada) REFERENCES ATL.Pessoa_Autorizada(Num_CC),
);

CREATE TABLE ATL.Atividades(
	Custo		INT	NOT NULL,
	ID			INT NOT NULL,
	Designacao	VARCHAR(30)	NOT NULL,
	PRIMARY KEY(ID),
);

CREATE TABLE ATL.Participa(
	ID_Turma		VARCHAR(3)	NOT NULL,
	ID_Atividade	INT			NOT NULL,
	PRIMARY KEY(ID_Turma, ID_Atividade),
	FOREIGN KEY(ID_Turma) REFERENCES ATL.Turma(Identificador),
	FOREIGN KEY(ID_Atividade) REFERENCES ATL.Atividades(ID),
);

CREATE TABLE ATL.Atividade(
	ID_Pagamento	INT	NOT NULL,
	PRIMARY KEY(ID_Pagamento),
	FOREIGN KEY(ID_Pagamento) REFERENCES ATL.Pagamento(ID),
);

CREATE TABLE ATL.Paga(
	ID_Pagamento_Atividade	INT	NOT NULL,
	ID_Turma				VARCHAR(3)	NOT NULL,
	PRIMARY KEY(ID_Pagamento_Atividade, ID_Turma),
	FOREIGN KEY(ID_Pagamento_Atividade) REFERENCES ATL.Atividade(ID_Pagamento),
	FOREIGN KEY(ID_Turma) REFERENCES ATL.Turma(Identificador),
);







