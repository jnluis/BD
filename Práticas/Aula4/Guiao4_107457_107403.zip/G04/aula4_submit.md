# BD: Guião 4

## ​Problema 4.1

### 1. Sistema de Gestão de um Rent-a-Car

[SQL DDL File](ex_4_1_1.sql "SQLFileQuestion")

![ex_4_1_1 diagram](ex_4_1_1.png "AnImage")

### 2. Sistema de Gestão de Reservas de Voos

[SQL DDL File](ex_4_1_2.sql "SQLFileQuestion")

![ex_4_1_2 diagram](ex_4_1_2.png "AnImage")

### 3. Sistema de Gestão de Stocks – Módulo de Encomendas

[SQL DDL File](ex_4_1_3.sql "SQLFileQuestion")

![ex_4_1_3 diagram](ex_4_1_3.png "AnImage")

### 4. Sistema de Prescrição Eletrónica de Medicamentos 

[SQL DDL File](ex_4_1_4.sql "SQLFileQuestion")

![ex_4_1_4 diagram](ex_4_1_4.png "AnImage")

### 5. Sistema de Gestão de Conferências

[SQL DDL File](ex_4_1_5.sql "SQLFileQuestion")

![ex_4_1_5 diagram](ex_4_1_5.png "AnImage")

### 6. Sistema de Gestão de ATL

[SQL DDL File](ex_4_1_6.sql "SQLFileQuestion")

![ex_4_1_6 diagram](ex_4_1_6.png "AnImage")
