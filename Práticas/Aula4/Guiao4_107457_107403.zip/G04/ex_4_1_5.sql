-- Exerc�cio 4.1.5;

DROP TABLE IF EXISTS G_Conferencias.Tem;
DROP TABLE IF EXISTS G_Conferencias.Artigo;
DROP TABLE IF EXISTS G_Conferencias.Estudante;
DROP TABLE IF EXISTS G_Conferencias.Comprovativo;
DROP TABLE IF EXISTS G_Conferencias.Nao_Estudante;
DROP TABLE IF EXISTS G_Conferencias.Participante;
DROP TABLE IF EXISTS G_Conferencias.Autor;
DROP TABLE IF EXISTS G_Conferencias.Pessoa;
DROP TABLE IF EXISTS G_Conferencias.Instituicao;
DROP SCHEMA IF EXISTS G_Conferencias;
GO

CREATE SCHEMA G_Conferencias;
GO

CREATE TABLE G_Conferencias.Instituicao(
	Nome		VARCHAR(30)	NOT NULL,
	Endereco	VARCHAR(40) NOT NULL,
	PRIMARY KEY(Nome),
);

CREATE TABLE G_Conferencias.Pessoa(
	Nome				VARCHAR(30)	NOT NULL,
	Email				VARCHAR(40),
	Nome_Instituicao	VARCHAR(30) NOT NULL,
	PRIMARY KEY(Nome),
	FOREIGN KEY (Nome_Instituicao) REFERENCES G_Conferencias.Instituicao(Nome),
);

CREATE TABLE G_Conferencias.Autor(
	Nome				VARCHAR(30)	NOT NULL,
	PRIMARY KEY(Nome),
	FOREIGN KEY (Nome) REFERENCES G_Conferencias.Pessoa(Nome),
);

CREATE TABLE G_Conferencias.Participante(
	Nome			VARCHAR(30)	NOT NULL,
	Morada			VARCHAR(40),
	Data_Inscricao	DATE		NOT NULL,
	PRIMARY KEY(Nome),
	FOREIGN KEY (Nome) REFERENCES G_Conferencias.Pessoa(Nome),
);

CREATE TABLE G_Conferencias.Nao_Estudante(
	Nome			VARCHAR(30)	NOT NULL,
	Ref_Pagamento	INT			NOT NULL,
	PRIMARY KEY(Nome),
	FOREIGN KEY (Nome) REFERENCES G_Conferencias.Participante(Nome),
);

CREATE TABLE G_Conferencias.Comprovativo(
	Localizacao_Eletronica	VARCHAR(20)	NOT NULL,
	Nome_Instituicao		VARCHAR(30)	NOT NULL,
	PRIMARY KEY(Localizacao_Eletronica),
	FOREIGN KEY (Nome_Instituicao) REFERENCES G_Conferencias.Instituicao(Nome),
);


CREATE TABLE G_Conferencias.Estudante(
	Nome				VARCHAR(30)	NOT NULL,
	Local_Comprovativo	VARCHAR(20)	NOT NULL,
	PRIMARY KEY(Nome),
	FOREIGN KEY (Nome) REFERENCES G_Conferencias.Participante(Nome),
	FOREIGN KEY (Local_Comprovativo) REFERENCES G_Conferencias.Comprovativo(Localizacao_Eletronica),
);

CREATE TABLE G_Conferencias.Artigo(
	Num_Resgisto	INT			NOT NULL,
	Titulo			VARCHAR(30)	NOT NULL,
	PRIMARY KEY(Num_Resgisto),
);

CREATE TABLE G_Conferencias.Tem(
	Num_Resgisto_Artigo	INT	NOT NULL,
	Nome_Autor			VARCHAR(30)	NOT NULL,
	PRIMARY KEY(Num_Resgisto_Artigo, Nome_Autor),
	FOREIGN KEY (Num_Resgisto_Artigo) REFERENCES G_Conferencias.Artigo(Num_Resgisto),
	FOREIGN KEY (Nome_Autor) REFERENCES G_Conferencias.Autor(Nome),
);



